import React from 'react';

import './ComponentTwo.css';

class ComponentTwo extends React.Component {
    render() {
        return (
            <h2 className="text-success card2">Hi From Component Two</h2>
        );
    }
}

export default ComponentTwo;
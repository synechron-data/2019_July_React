// import React from 'react';

// class ComponentOne extends React.Component {
//     render() {
//         return (
//             <h2>Hi From Component One</h2>
//         );
//     }
// }

// export default ComponentOne;

// -----------------------------------------------
// import React, { Component } from 'react';

// class ComponentOne extends Component {
//     render() {
//         return (
//             <h2>Hi From Component One</h2>
//         );
//     }
// }

// export default ComponentOne;

// ------------------------------------------------
// import React from 'react';

// // function ComponentOne() {
// //     return (
// //         <h2>Hi From Component One</h2>
// //     );
// // }

// const ComponentOne = function () {
//     return (
//         <h2>Hi From Component One</h2>
//     );
// }

// export default ComponentOne;

// -------------------------------------------------
import React from 'react';

// const ComponentOne = () => {
//     return (
//         <h2>Hi From Component One - Arrow</h2>
//     );
// }

const ComponentOne = () => (
    <h2 className="text-info">Hi From Component One - Arrow</h2>
);


export default ComponentOne;
import React, { Component } from 'react';

class ComponentWithState extends Component {
    constructor() {
        super();
        this.state = { name: "Synechron" };
        console.log("Ctor: ", this.state);
    }

    render() {
        console.log("Render: ", this.state);

        return (
            <div>
                <h2 className="text-info">Hello, {this.state.name}</h2>
            </div>
        );
    }
}

export default ComponentWithState;
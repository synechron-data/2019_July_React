import React, { Component } from 'react';

class ComponentWithProps extends Component {
    constructor(props) {
        super(props);
        // this.props.name = "ABC";   // Props are readonly
        console.log("Ctor, State: ", this.state);
        console.log("Ctor, Props: ", this.props);

        // this.state = this.props;

        // this.state = Object.assign({}, this.props);
        this.state = { ...this.props };
    }

    render() {
        console.log("Render, State: ", this.state);
        console.log("Render, Props: ", this.props);

        this.state.name = this.state.name.toUpperCase();

        return (
            <div>
                <h2 className="text-info">Company Name: {this.props.name}</h2>
                <h2 className="text-info">City Name: {this.props.city} </h2>
                <br />
                <h2 className="text-info">Company Name: {this.state.name}</h2>
                <h2 className="text-info">City Name: {this.state.city} </h2>
            </div>
        );
    }
}

export default ComponentWithProps;
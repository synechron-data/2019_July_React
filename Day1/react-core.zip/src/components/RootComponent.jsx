import React, { Component } from 'react';

// import ComponentOne from './2_multi-components/ComponentOne';
// import ComponentTwo from './2_multi-components/ComponentTwo';

// import ComponentOne from './3_components-with-css/ComponentOne';
// import ComponentTwo from './3_components-with-css/ComponentTwo';

// import ComponentOne from './4_external-css/CompOne/ComponentOne';
// import ComponentTwo from './4_external-css/CompTwo/ComponentTwo';

import ComponentOne from './5_css-modules/CompOne/ComponentOne';
import ComponentTwo from './5_css-modules/CompTwo/ComponentTwo';
import ComponentWithState from './6_ComponentWithState';
import ComponentWithProps from './7_ComponentWithProps';
import Button from './8_CompWithBehavior';

class RootComponent extends Component {
    test() {
        alert("Hello from root");
    }

    render() {
        return (
            <div className="container">
                {/* <ComponentOne />
                <ComponentTwo /> */}
                {/* <ComponentWithState/> */}
                {/* <ComponentWithProps name={"Synechron"} city={"Pune"} id={101} display={this.test} /> */}
                <Button/>
            </div>
        );
    }
}

export default RootComponent;
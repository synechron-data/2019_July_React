import React from 'react';

class HelloComponent extends React.Component {
    render() {
        return (
            <React.Fragment>
                <h2>Hello World!</h2>
                {/* <h2>Hi World!</h2> */}
            </React.Fragment>
        );
    }
}

export default HelloComponent;
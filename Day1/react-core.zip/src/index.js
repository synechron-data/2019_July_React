// import React from 'react';
// import ReactDOM from 'react-dom';
// import RootComponent from './components/RootComponent';

// import HelloComponent from './components/1_HelloComponent';
// import ComponentOne from './components/2_multi-components/ComponentOne';
// import ComponentTwo from './components/2_multi-components/ComponentTwo';

// ReactDOM.render(<HelloComponent />, document.getElementById('root'));

// ReactDOM.render(<ComponentOne />, document.getElementById('root1'));
// ReactDOM.render(<ComponentTwo />, document.getElementById('root2'));

// // ReactDOM.render([<ComponentOne />, <ComponentTwo />], document.getElementById('root3'));
// ReactDOM.render(<React.Fragment>
//     <ComponentOne />
//     <ComponentTwo />
// </React.Fragment>, document.getElementById('root3'));

import 'bootstrap/scss/bootstrap.scss';

import React from 'react';
import ReactDOM from 'react-dom';
import RootComponent from './components/RootComponent';

// --------------------------- Including Bootstrap 3
// npm install --save bootstrap@3 jquery

// import $ from 'jquery';
// import 'bootstrap/dist/css/bootstrap.css';

// window.$ = $;
// window.jQuery = $;
// global.jQuery = $;

// require('bootstrap');


// --------------------------- Including Bootstrap 4
// npm install --save bootstrap popper.js jquery
// npm install --save-dev node-sass

import $ from 'jquery';

window.$ = $;
window.jQuery = $;
global.jQuery = $;

require('bootstrap');

ReactDOM.render(<RootComponent />, document.getElementById('root'));

import React, { Component } from 'react';
import { connect } from 'react-redux';
import ProductListComponent from '../../components/products/ProductListComponent';

import * as productActions from '../../actions/productActions';
import AddProductButton from '../../components/products/AddProductButton';

class ProductsContainer extends Component {
    constructor(props) {
        super(props);
        this.deleteProduct = this.deleteProduct.bind(this);
    }

    render() {
        return (
            <React.Fragment>
                <br />
                <AddProductButton />
                <br /><br />
                <ProductListComponent products={this.props.products}
                    onDelete={this.deleteProduct} />
            </React.Fragment>
        );
    }

    deleteProduct(p, e) {
        this.props.deleteProduct(p);
    }

    componentDidMount() {
        this.props.loadProducts();
    }
}

function mapStateToProps(state) {
    return {
        products: state.productReducer
    };
}

function mapDispatchToProps(dispatch) {
    return {
        loadProducts: () => dispatch(productActions.loadProducts()),
        deleteProduct: (p) => dispatch(productActions.deleteProduct(p))
    };
}

export default connect(mapStateToProps, mapDispatchToProps)(ProductsContainer);
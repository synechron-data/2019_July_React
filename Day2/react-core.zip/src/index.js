import React from 'react';
import ReactDOM from 'react-dom';

import $ from 'jquery';
import 'bootstrap/scss/bootstrap.scss';
import RootComponent from './components/RootComponent';

window.$ = $;
window.jQuery = $;
global.jQuery = $;

require('bootstrap');

ReactDOM.render(<RootComponent />, document.getElementById('root'));
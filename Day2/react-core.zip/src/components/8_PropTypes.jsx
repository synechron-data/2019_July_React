import React, { Component } from 'react';
import PropTypes from 'prop-types';

class PTComponent extends Component {
    render() {
        var name = this.props.ename.toUpperCase();
        return (
            <div>
                <h3 className="text-info">Hello, {name}</h3>
                <h3 className="text-info">Age, {this.props.age}</h3>
            </div>
        );
    }

    static get propTypes() {
        return {
            ename: PropTypes.string.isRequired,
            // age: PropTypes.number.isRequired
            age: function (props, propName, componentName) {
                if (!props[propName])
                    return new Error(`${componentName} --- ${propName}, is required.`);
                if (!props[propName] < 30)
                    return new Error(`${componentName} --- ${propName}, must be greater than 30.`);
            }
        };
    }
}

class PTRoot extends Component {
    render() {
        return (
            <div>
                <PTComponent ename={"abhijeet"} age={10} />
            </div>
        );
    }
}

export default PTRoot;
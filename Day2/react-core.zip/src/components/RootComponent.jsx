/* eslint-disable */
import React, { Component } from 'react';
import EventComponent from './1_ReactEventObject';
import CounterAssignment from './2_CounterAssignment';
import DataFlowAssignment from './3_DataFlowAssignment';
import ControlledVsUncontrolledComponent from './4_ControlledVsUncontrolledComponent';
import CalculatorAssignment from './5_CalculatorAssignment';
import ListRoot from './6_ListComponent';
import FormAssignment from './7_FormAssignment';
import PTRoot from './8_PropTypes';

class RootComponent extends Component {
    render() {
        return (
            <div className="container">
                {/* <EventComponent/> */}
                {/* <CounterAssignment /> */}
                {/* <DataFlowAssignment/> */}
                {/* <ControlledVsUncontrolledComponent/> */}
                {/* <CalculatorAssignment /> */}
                {/* <ListRoot /> */}
                {/* <FormAssignment /> */}
                <PTRoot />
            </div>
        );
    }
}

export default RootComponent;
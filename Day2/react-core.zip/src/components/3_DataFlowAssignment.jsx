import React, { Component } from 'react';

const Result = (props) => (
    <h2 className="text-info">Result: {props.result}</h2>
);

const Button = (props) => (
    <button className="btn btn-info" onClick={(e) => {
        props.handleClick(props.incBy, e);
    }}>
        Add {props.incBy}
    </button>
);

class DataFlowAssignment extends Component {
    constructor(props) {
        super(props);
        this.state = { result: 0 };
        this.updateState = this.updateState.bind(this);
    }

    updateState(by, e) {
        this.setState({ result: this.state.result + by });
    }

    render() {
        return (
            <div>
                <Result result={this.state.result} />
                <Button incBy={5} handleClick={this.updateState} />
                <Button incBy={10} handleClick={this.updateState} />
                <Button incBy={15} handleClick={this.updateState} />
                <Button incBy={20} handleClick={this.updateState} />
            </div>
        );
    }
}

export default DataFlowAssignment;
import React from 'react';
import ReactDOM from 'react-dom';

import $ from 'jquery';
import 'bootstrap/scss/bootstrap.scss';
import RootComponent from './components/root/RootComponent';
import { BrowserRouter } from "react-router-dom";

window.$ = $;
window.jQuery = $;
global.jQuery = $;

require('bootstrap');

ReactDOM.render(<BrowserRouter>
    <RootComponent />
</BrowserRouter>, document.getElementById('root'));
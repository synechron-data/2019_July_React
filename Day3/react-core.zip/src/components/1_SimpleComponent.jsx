import React, { Component } from 'react';
import DataTable from './common/DataTable';
import PropTypes from 'prop-types';

class SimpleComponent extends Component {
    
    render() {
        var name = this.props.ename.toUpperCase();
        return (
            <div>
                <h3 className="text-info">Hello, {name}</h3>
            </div>
        );
    }

    static get propTypes() {
        return {
            ename: PropTypes.string.isRequired
        }
    }
}

class SimpleComponentRoot extends Component {
    render() {
        return (
            <div>
                <SimpleComponent ename={"manish"}/>
                {/* <DataTable items={[10, 20, 30]} /> */}
            </div>
        );
    }
}


export default SimpleComponentRoot;
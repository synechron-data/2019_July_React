/* eslint-disable */
import React, { Component } from 'react';
import SimpleComponentRoot from './1_SimpleComponent';
import ErrorHandler from './common/ErrorHandler';
import AjaxComponent from './2_AjaxComponent';
import PropDrillingDemo from './3_PropDrilling';
import ContextAPIDemo from './5_ContextAPI';

class RootComponent extends Component {
    render() {
        return (
            <div className="container">
                <ErrorHandler>
                    {/* <SimpleComponentRoot /> */}
                    {/* <AjaxComponent/> */}
                    {/* <PropDrillingDemo /> */}
                    <ContextAPIDemo/>
                </ErrorHandler>
            </div>
        );
    }
}

export default RootComponent;
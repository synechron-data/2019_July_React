import React, { Component } from 'react';
import DataTable from './common/DataTable';
import postAPIClient from '../services/post.service';

const { Provider, Consumer } = React.createContext();

class ContextAPIDemo extends Component {
    constructor(props) {
        super(props);
        this.state = { posts: [], message: "Loading Data, please wait..." };
    }

    render() {
        return (
            <React.Fragment>
                <h1 className="text-primary">Parent</h1>
                <div className="row">
                    <h3 className="text-warning">{this.state.message}</h3>
                </div>
                <Provider value={this.state.posts}>
                    <ChildOne />
                </Provider>
            </React.Fragment>
        );
    }

    componentDidMount() {
        postAPIClient.getAllPosts().then((data) => {
            this.setState({ posts: [...data], message: "" });
        }, (eMsg) => {
            this.setState({ message: eMsg });
        })
    }
}

class ChildOne extends Component {
    render() {
        return (
            <div>
                <h3 className="text-success">Child One</h3>
                <ChildTwo />
            </div>
        );
    }
}

class ChildTwo extends Component {
    render() {
        return (
            <div>
                <h3 className="text-info">Child Two</h3>
                <Consumer>
                    {
                        (data) =>
                            <DataTable items={data}>
                                <h4 className="text-success">Posts Table</h4>
                            </DataTable>
                    }
                </Consumer>
            </div>
        );
    }
}

export default ContextAPIDemo;